 <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Start Bootstrap </div>
      <div class="list-group list-group-flush">
       <a href="index.php" class="list-group-item list-group-item-action bg-light <?php if($page == 'home') {echo "active";} ?>">Dashboard</a>
        <a href="apply_leave.php" class="list-group-item list-group-item-action bg-light <?php if($page == 'apply_leave') {echo "active";} ?>">Apply Leave</a>
        <a href="leave_history.php" class="list-group-item list-group-item-action bg-light <?php if($page == 'leave_history') {echo "active";} ?>">Leave History</a>
        
      </div>
    </div>